
![Book cover](_cover.jpg?raw=true)

# Deep Learning Book
MIT Deep Learning Book in PDF format

This book was downloaded in HTML form and conviniently joined as a single PDF file for your enjoyment. PLEASE SUPPORT IAN GOODFELLOW and the authors if you can purchase the paper book at Amazon. It is not expensive ($72) and probably contains content that is newer and without typographic mistakes.

[Deep Learning - Adaptive Computation and Machine Learning series](http://amzn.to/2qlQqZs) by Ian Goodfellow (Author), Yoshua Bengio  (Author), Aaron Courville  (Author)

For questions regarding the contents of the book, we encourage you to ask them on the book's forum 
https://groups.google.com/forum/#!forum/deeplearningbook

From http://www.deeplearningbook.org/

    An MIT Press book

    Ian Goodfellow, Yoshua Bengio and Aaron Courville

    The Deep Learning textbook is a resource intended to help students and practitioners enter the field of machine learning in general and deep learning in particular. The online version of the book is now complete and will remain available online for free. The print version will be available for sale soon.

    Citing the book

    To cite this book, please use this bibtex entry:

    @unpublished{Goodfellow-et-al-2016-Book,
        title={Deep Learning},
        author={Ian Goodfellow, Yoshua Bengio, and Aaron Courville},
        note={Book in preparation for MIT Press},
        url={http://www.deeplearningbook.org},
        year={2016}
    }


Many thanks ~
